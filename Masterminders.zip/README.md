# Masterminders
Programmet bruger Pillow, tkinter og webbrowser
